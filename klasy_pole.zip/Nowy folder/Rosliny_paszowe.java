package pole;

public class Rosliny_paszowe extends Uprawa {
	
	private boolean czyPasza;
	
	public Rosliny_paszowe(String nazwa, boolean gotoweDoZebrania, int cena, int czasProdukcji, String adresIkonki,boolean czyPasza)
	{
		super(nazwa, gotoweDoZebrania, cena, czasProdukcji, adresIkonki);
		this.czyPasza = czyPasza;
	}

	public boolean getCzyPasza() {
		return czyPasza;
	}

	public void setCzyPasza(boolean czyPasza) {
		this.czyPasza = czyPasza;
	}
	
	public void wytworzPasze()
	{
		czyPasza = true;
	}
	
	

}
