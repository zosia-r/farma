import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import  Gra.Gra;
import Farma.Farma;
import Kawałek_Ziemi.Kawałek_Ziemi;
import Uprawy.Uprawy;
import Zboża.Zboża;

public class main3 {
    public static void main(String[] args)
    {
//        // Tworzymy ramkę (okno)
//        JFrame frame = new JFrame("Prosty Interfejs Graficzny");
//        // Tworzymy przycisk
//        JButton button = new JButton("Gra farma!");
//        // Dodajemy obsługę zdarzeń (event listener) do przycisku
//        button.addActionListener(e -> {
//            // Wyświetlamy komunikat po kliknięciu przycisku
//            JOptionPane.showMessageDialog(frame, "under construction");
//        });
//        // Dodajemy przycisk do ramki
//        frame.getContentPane().add(button);
//        // Ustawiamy rozmiar ramki
//        frame.setSize(300, 200);
//        // Ustawiamy operację zamknięcia ramki
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        // Wyświetlamy ramkę
//        frame.setVisible(true);
        Zboża zboże1 = new Zboża();
        zboże1.getStan();
    }
}

